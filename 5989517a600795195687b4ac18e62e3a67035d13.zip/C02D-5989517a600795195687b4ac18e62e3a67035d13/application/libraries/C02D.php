<?php
class C02D{
	public static $title= "Carbon Diary";
	public static $footer= "&copy; 2012, Carbon Diary (C02D)";

	public static $markers= [['pitch', 'Person'], ['star', 'Star'], ['bakery', 'Croissant'], ["marker", "Marker Solid"],["marker-stroked", "Marker Stroke"],["cross", "Cross"],["star", "Star solid"],["star-stroked", "Star stroked"],["triangle", "Triangle solid"],["triangle-stroked", "Triangle stroked"],["square", "Square solid"],["square-stroked", "Square stroked"],["circle", "Circle solid"],["circle-stroked", "Circle stroked"]];

	public static $introtext= "<b>Welcome to Carbon Diary</b>,<br/><br/>The new innovative web app for phones that checks your daily Carbon footprint.";


}