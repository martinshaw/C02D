<?php
class Carbonmarker extends Eloquent {
     public static $table = 'carbon_mapping_points'; 
}