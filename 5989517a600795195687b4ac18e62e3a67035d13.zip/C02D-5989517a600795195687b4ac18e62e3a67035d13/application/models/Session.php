<?php
class Session extends Eloquent {
}
