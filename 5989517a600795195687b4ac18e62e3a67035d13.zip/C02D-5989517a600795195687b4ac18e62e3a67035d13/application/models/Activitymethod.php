<?php
class Activitymethod extends Eloquent {
	 public static $table = 'activitymethods';
}
