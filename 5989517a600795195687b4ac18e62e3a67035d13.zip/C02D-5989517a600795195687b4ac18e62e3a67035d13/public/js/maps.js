$(function(){
	$("#mapbox").height(window.innerHeight-400);
});