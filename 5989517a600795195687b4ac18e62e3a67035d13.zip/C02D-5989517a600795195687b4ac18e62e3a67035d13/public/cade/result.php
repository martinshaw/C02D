<?php
if(isset($_POST["cars"])){
	echo "You selected: ". $_POST["cars"];
}
?>