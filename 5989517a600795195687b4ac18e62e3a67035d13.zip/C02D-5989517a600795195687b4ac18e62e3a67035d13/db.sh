#!/bin/bash
mysql -h yrs13 -u root -pmondriot